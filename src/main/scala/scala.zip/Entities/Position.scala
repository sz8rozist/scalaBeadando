package Entities

/**
 * Position
 * @param pozíció x koordinátája
 * @param pozíció y koordinátája
 */
case class Position(x: Double, y: Double)
