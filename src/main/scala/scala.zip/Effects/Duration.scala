package Effects

/**
 * Egy speciális effect
 */
case class Duration()
